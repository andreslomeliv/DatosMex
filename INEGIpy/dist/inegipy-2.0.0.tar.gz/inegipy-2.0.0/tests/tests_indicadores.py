from INEGIpy import Indicadores
import pandas as pd

def test_obtener_df():
    indicadores = Indicadores("92170321-528f-f1dd-5d59-f8613e072746")
    df, meta = indicadores.obtener_df(
        ["5300000025"],
        nombres=None,
        inicio=None,
        fin=None,
        clave_area='00',
        metadatos=True
    )
    assert isinstance(df, pd.DataFrame)

def test_obtener_df_metadatos():
    indicadores = Indicadores("92170321-528f-f1dd-5d59-f8613e072746")
    df, meta = indicadores.obtener_df(
        ["5300000025"],
        nombres=None,
        inicio=None,
        fin=None,
        clave_area='00',
        metadatos=True
    )
    assert isinstance(meta, pd.DataFrame)

def test_catalogo_indicadores():
    indicadores = Indicadores("92170321-528f-f1dd-5d59-f8613e072746")
    df = indicadores.catalogo_indicadores("BISE")
    assert isinstance(df, pd.DataFrame)

def test_consulta_metadatos():
    indicadores = Indicadores("92170321-528f-f1dd-5d59-f8613e072746")
    metadatos = indicadores.obtener_df(
        ["5300000025"],
        nombres=None,
        inicio=None,
        fin=None,
        clave_area='00',
        metadatos=True
    )[1]
    df = indicadores.consulta_metadatos(metadatos)
    assert isinstance(df, pd.DataFrame)

